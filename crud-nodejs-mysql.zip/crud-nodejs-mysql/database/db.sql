drop database if exists crudnodejsmysql;
CREATE DATABASE crudnodejsmysql;



use crudnodejsmysql;


drop table if exists customer;
CREATE TABLE customer (
  id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(50) NOT NULL,
  address VARCHAR(100) NOT NULL,
  phone VARCHAR(15)
);

DROP TABLE IF EXISTS cliente;
CREATE TABLE cliente (
    DNI      MEDIUMINT   not null AUTO_INCREMENT primary key,
    nombre   varchar(25) not null,
    apellido varchar(25) not null
);


-- to show all tables
show tables;

-- to describe table
describe customer;


