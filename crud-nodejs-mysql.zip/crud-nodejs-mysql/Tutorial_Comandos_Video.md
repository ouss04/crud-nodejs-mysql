creamos la carpeta crud_node_mysql

npm init --yes (para crear el archivo package.json(el archivo principal  que describe el nombre y la version etc, de nuesto proyecto ))

```bash
mkdir crud_node_mysql
npm init --yes
```

vamos a instalar los modulos que necesetamos para crear esta app:(
    express 
    mysql 
    express-myconnection
    morgan 
    ejs)
```bash
npm install express mysql express-myconnection morgan ejs
```

creamos una carpeta y la llamamos src
```bash
mkdir /crud_node_mysql/src
```

crear un archivo llamado app con la extension javasctipt
```bash
touch /crud_node_mysql/src/app.js
```

dento del archivo app colocamos este codigo:
```javascript
#src/app.js

const express = require('express');
const app = express();
app.listen(app.get('port'), () => {
    console.log ('server on port 3000');
});
```

utilizamos el comando node src/app.js para iniciar el servidor despues entramos al un navegador y panemos la ruta localhost:3000
```bash
node src/app.js
```
![](/home/ouss/video/comandos_video/captura1.png)



instalamos el modulo nodemon
```bash
npm install nodemon -D
```
```javascript
#src/app.js
const express = require('express');
const app = express();

//setting  //new
app.set('port', process.env.PORT || 3000);  //new

app.listen(app.get('port'), () => {         //new
    console.log ('server on port 3000');
});
```
dentro de package.json borramos "test": "echo \"error: no test specified \" && exit 1"

y ponemos el seguente codejo
```javascript
"dev": "nodemon src/app.js"
```

ahora utlizamos el comando npm run dev para eniciar el servidor

```bash
npm run dev
```
dentri de la carpeta src vamos a crear un acarpeta un acarpeta llamada views
```bash
mkdir /src/views
```

con esta configuracion que vamos a poner queremos decir que la carpeta views se encuentra de la ruta ../src/..
```javascript
#src/app.js

const express = require('express');
const path = require('path'); //new
const app = express();

//setting  
app.set('port', process.env.PORT || 3000);
app.set('view engine', 'ejs');  //new
app.set('views', path.join(__dirname, 'views')); //new

app.listen(app.get('port'), () => {         
    console.log ('server on port 3000');
});
```


```javascript
#src/app.js
...
const morgan = require('morgan'); //new
const mysql = require('mysql'); //new
const myConnection = require('express-myconnection'); //new
...

...
//middlewares       //new
app.use(morgan('dev'));         //new
app.use(myConnection(mysql, {       //new
    host: 'localhost',              //new
    user: 'root'                    //new
    password: 'contraseña',         //new
    port: 3306,                     //new
    database: 'crudnodejsmysql'     //new
}, 'single'));                      //new
```


abrimos otro terminal y ejecutamos mysql con el comando
```bash
mysql -u root -p
```
y ponemos la contraseña que hemos puesto en #src/app.js middlewares en esta caso hemos puesto contraseña

crear nueva carpeta llamada database que se encarga de tener los scripts de la base de datos.
```bash
mkdir /crud_node_mysql/database
```
creamos un archivo dentro de la carpeta database con el nombre db.sql
```bash
touch /database/db.sql
```


vamso a colocar este codigo dentro del archivo db.sql
```sql
-- creating the database
CREATE DATABASE crudnodejsmysql;

--using the database
use crudnodejsmysql;

-- creating a table
CREATE TABLE customer (
    id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    address VARCHAR(100) NOT NULL,
    phone VARCHAR(15)
);
--tp show all tables
SHOW TABLES;

-- to describe the table
describe customer;
```
copias esta codejo que acabamos de escribir y lo pegamos en la consola para crear la tabla y mostrarla.

utilizamos el siguente comando para saber si nuestra base de datos tiene datos 
```sql
select * from customer;
```

iniciamos el servidor y creamos tres carpetas llamadas routes , controllers y public
la carpeta routes es para poner todas la rutas del  servedor
la carpeta controllers es para ejecutar las rutas.
la carpeta public sirve para colocar los codijos fuentes (css ...)

```bash
npm run dev

mkdir /src/routes
mkdir /src/controller
mkdir /src/public
```
creamos un archivo dentro de la carpeta routes llamado customer.js
```bach
touch /src/routes/customer.js
```

agragamos este codigo en el archivo customer.js

```javascript
#src/routes/customer.js
const express = require('express');
const router = express.Router();

module.exports = router;
```


inmportamos este archivo en app.js
```javascript
#src/app.js

...
//importing routes                                      //new
const customerRoutes = require('./routes/customer');    //new
...
//routes                                                //new
app.use('/', customerRoutes);                           //new
//static files                                          //new
app.use('express.static'(path.join(__dirname, 'public')));      //new
...
```

creamos un archivo llamado customerController.js dentro de la carpeta controllers
```bash
touch /src/controllers/customerController.js
```

```javascript
#src/routes/customer.js
const express = require('express');
const router = express.Router();

const customerController = require('../controllers/customerController')     //new

router.get('/', customerControler.list);              //new
module.exports = router;

```


```javascript
#src/controller/customerController.js

const controller = {};

controller.list = (req, res ) => {
    res.send('hello world!');
};

module.exports = controller;
```
creamos una carpeta llamada customer.ejs
```bash
mkdir /src/views/customers.ejs
```
```javascript
#src/controller/customerController.js

const controller = {};

controller.list = (req, res ) => {                  //NEW
    req.getConnection((err, conn)=> {               //NEW
        conn.query('SELECT * FROM customer', (err, customers)=> {       //NEW
            if (err){                                                   //NEW
                res.json(err);                                          //NEW
            }                                                           //NEW
            console.log(customers);                                     //NEW            
            res.render('customers', {                                   //new
                data: customers                                         //new
            });                                    //NEW
        });                                                             //NEW    
    });                                                                 //NEW
};                                                                      //NEW

module.exports = controller;
```
creamos una carpeta llamada partials y dentro de ella creamos dos archivos llamados _header.ejs y _footer.ejs
```bash
mkdir /home/ouss/video/prb_video/src/views/partials
touch /src/views/partials/_header.ejs
touch /src/views/partials/_footer.ejs
```
agregamos el siguente codigo a los archivo que hemos creado para dar formato a nuestra pagina web
```javascript
#/src/views/partials/_header.ejs
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>CRUD Nodejs Mysql</title>
        <link rel="stylsheet" herf="https://bootswatch.com/4/lux/bootstrap.min.css">
    </head>
    <body>
        <nav class= "navbar navbar-dark bg-dark">
            <a herf="/" class="navbar-brand">CRUD Nodejs Mysql</a>
        </nav>
```
```javascript
#/src/views/partials/_footer.ejs
    </body>
</html>
```

```html
#src/views/customers.ejs
<% include partials/_header %>
<div class="container">
    <div class="row mt-5">
        <div class="col-md-7">
        </div>
        <div class="col-md-5">
            <div class="card">
                <div class="card-body">
                    <form action="/add" method="post">
                        <div class="from-group">
                            <input type="text" name="name" placeholder="Name" class="from-control">
                        </div>
                        <div class="from-group">
                            <input type="text" name="address" placeholder="Address" class="from-control">
                        </div>
                        <div class="from-group">
                            <input type="text" name="phone" placeholder="Phone" class="from-control">
                        </div>
                        <button type="submit" class="btn btn-primary">
                            save customer
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<% include partials/_footer %>
```


```javascript
#src/routes/customers.js
...

router.post('/add', customereController.save);      //new
module.exports = router;
```




```javascript
#src/controllers/customerController.js
...
controller.save = (req, res) => {                       //new
    console.log(req.body);              //new
    
    req.getConnection((err, conn)) => {             //new
        conn.query('INSERT INTO customer set ?', [data], (err, customer) => {           //new
            res.redirect('/');              //new
        });             //new
    }               //new
};                                      //new
module.exports = controller;
```

```javascript
#src/app.js
//middlewares
...
app.use(express.urlencoded({extended: false}));
...
```
```html
#src/views/customers.ejs
<% include partials/_header %>

<div class="container">
    <div class="row mt-5">
        <div class="col-md-7">
        <table class="table table-border table-hover">
            <thead>                   //new                                                 
                <tr>                                //new
                    <th>Nº</th>                             //new
                    <th>Name</th>                               //new
                    <th>Address</th>                                //new
                    <th>Phone</th>                              //new
                    <th>Action</th>                             //new
                </tr>                               //new
            </thead>                                //new
            <tbody>                             //new
                <% if (data) { %>                                //new
                    <% for (var i = 0; i< data.lenght; i++) {%>                  //new
                        <tr>                                //new
                            <td><%= (i + 1) %></td>                             //new
                            <td><%= data[i].name %></td>                                //new
                            <td><%= data[i].Address %></td>                             //new
                            <td><%= data[i].Phone %></td>                               //new
                            <td>
                                <a herf="/delete/<%= data[i].id %>" class="btn btn-danger">Delete</a>
                            </td>                               
                        </tr>                               //new
                    <% } %>                             //new
                <% } %>                             //new
            </tbody>                                //new
        </table>                                //new
        </div>
        <div class="col-md-5">
            <div class="card">
                <div class="card-body">
                    <form action="/add" method="post">
                        <div class="from-group">
                            <input type="text" name="name" placeholder="Name" class="from-control">
                        </div>
                        <div class="from-group">
                            <input type="text" name="address" placeholder="Address" class="from-control">
                        </div>
                        <div class="from-group">
                            <input type="text" name="phone" placeholder="Phone" class="from-control">
                        </div>
                        <button type="submit" class="btn btn-primary">
                            save customer
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<% include partials/_footer %>
```

```javascript
#src/controllers/customerController.js
...
controller.delete = (req, res) => {

};

module.exports = controller;
```

```javascript
#/src/routes/customer.js
...
router.get('/delete', customerController.delete);   //new
```